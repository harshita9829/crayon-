package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaCrudRepository5Feb2021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
