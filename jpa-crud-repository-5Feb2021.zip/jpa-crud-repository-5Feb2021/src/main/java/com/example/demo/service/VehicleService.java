package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Vehicle;
import com.example.demo.repository.VehicleRepository;

@Component("vehicleService")
public class VehicleService implements IVehicleService {

	@Autowired
	private VehicleRepository vehicleRepository;
	
	
	@Override
	public void create(Vehicle vehicle) {
		vehicleRepository.save(vehicle);
	}

	@Override
	public List<Vehicle> read(){
		return vehicleRepository.findAll();
	}
	
	@Override
	public Vehicle read(Integer id){
		return vehicleRepository.findById(id).get();
	}
	
	@Override
	public void update(Vehicle vehicle)
	{
		vehicleRepository.save(vehicle);
	}
	@Override
	public void delete(Vehicle vehicle)
	{
		vehicleRepository.delete(vehicle);
	}
	
	@Override
	public List<Vehicle> findVehicleByType(String type)
	{
		return vehicleRepository.findVehicleByType(type);
	}

}
