package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Course;
import com.example.demo.entity.Upload;

import com.example.demo.repository.UploadRepository;



@Component("UploadService")
public class UploadService {
	@Autowired
	private UploadRepository uploadRepository;
	

	public Upload create(Upload upload)			
	{
		return uploadRepository.save(upload);
	}
	public List<Upload> read()
	{
		return uploadRepository.findAll();
	}
	
	public List<Course> findCoursesByTeacherId(Integer teacherId)
	{
		return uploadRepository.findCoursesByTeacherid(teacherId);
	}
}
