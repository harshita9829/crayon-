package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Chapter;
import com.example.demo.entity.Course;
import com.example.demo.repository.ChapterRepository;

@Component("chapterService")
public class ChapterService implements IChapterService {

	@Autowired
	private ChapterRepository chapterRepository;
	
	@Override
	public void createChapter(Chapter chapter) {
		chapterRepository.save(chapter);
	}
	
	@Override
	public List<Chapter> readAllChapter(){
		return chapterRepository.findAll();
	}
	
	@Override
	public void updateChapter(Chapter chapter) {
		chapterRepository.save(chapter);
	}
	
	@Override
	public Chapter readChapterById(Integer id) {
		return chapterRepository.findById(id).get();
		
	}
	
	@Override
	public void deleteChapter(Chapter chapter) {
		chapterRepository.delete(chapter);
	}

	public List<Chapter> getChapterByCourseId(Integer courseId)
	{
		return chapterRepository.getChapterByCourseId(courseId);
	}
}

