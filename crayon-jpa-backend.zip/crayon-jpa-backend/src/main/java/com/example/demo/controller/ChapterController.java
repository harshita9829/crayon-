package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Chapter;
import com.example.demo.entity.Course;
import com.example.demo.service.ChapterService;
import com.example.demo.service.CourseService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/chapter")
public class ChapterController {

	@Autowired
	ChapterService chapterService;
	@Autowired
	CourseService courseService;
	
	@GetMapping("/")
	public List<Chapter> getAllChapters()
	{
		return chapterService.readAllChapter();
	}
	
	@GetMapping("/{id}")
	public Chapter findChapterById(@PathVariable("id") Integer id)
	{
		System.out.println(id);
		Chapter chapter=null;
		try {
		chapter = chapterService.readChapterById(id);
		}catch(Exception ex)
		{
			return null;
		}
		return chapter;
	}
	
	@PostMapping("/")
//	public void addChapter(@RequestBody Chapter chapter)
	public void addChapter(@RequestParam("courseId") String courseId, @RequestParam("chapterId")String chapterId, @RequestParam("chapterName")String chapterName)
	{
		//get courseId first. then findCourseById and then chapter.setCourse(course). then add chapter
		System.out.println("Course Id:"+courseId);
		System.out.println("Chapter Id:"+chapterId);
		System.out.println("chapter Name:"+chapterName);
		
		//find Course object using courseId;
		Course course = courseService.readCourseById(Integer.valueOf(courseId));
		if(course==null)
		{
			System.out.println("No course found for course id "+courseId);
			return;
		}
		Chapter chapter =new Chapter(Integer.parseInt(chapterId), chapterName, course);
		
		chapterService.createChapter(chapter);
		System.out.println("Last line of add Chapter");
	}
	
	@PutMapping("/")
	public void updateChapter(@RequestBody Chapter chapter)
	{
		chapterService.updateChapter(chapter);
	}
	
	@DeleteMapping("/{id}")
	public void deleteChapter(@PathVariable("id") Integer id)
	{
		
		Chapter chapter=findChapterById(id);
		chapterService.deleteChapter(chapter);
	}
	
	@GetMapping("/chapter/{id}")
	public List<Chapter> findChapterByCourseId(@PathVariable("id") Integer courseId) {
		
		
		List<Chapter> chapter = chapterService.getChapterByCourseId(courseId);
		return chapter;
		
	}
}
