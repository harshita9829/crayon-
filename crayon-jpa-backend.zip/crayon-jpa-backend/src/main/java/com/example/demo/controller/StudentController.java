package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Course;
import com.example.demo.entity.Student;
import com.example.demo.entity.User;
import com.example.demo.service.EnrollmentService;
import com.example.demo.service.StudentService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/student")
public class StudentController {
	@Autowired
	StudentService studentService;
	@Autowired
	EnrollmentService enrollmentservice;
	
	@GetMapping("/")
	public List<Student> getAllStudents()
	{
		return studentService.read();
	}
	
	@GetMapping("/{id}")
	public Student findStudentById(@PathVariable("id") Integer id)
	{
		Student student=null;
		try {
		student = studentService.read(id);
		}catch(Exception ex)
		{
			return null;
		}
		return student;
	}
	@GetMapping("/student/{id}")
	public List<Course> findCoursesByStudentId(@PathVariable("id") Integer studentId) {
		
		
		List<Course> course = enrollmentservice.findCoursesByStudentId(studentId);
		return course;
		
	}

	@PostMapping("/")
	public void addStudent(@RequestBody Student student)
	{
		student.setRole("student");
		studentService.create(student);
	}
	
	@PutMapping("/")
	public void updateStudent(@RequestBody Student student)
	{
		studentService.update(student);
	}
	
	@DeleteMapping("/{id}")
	public void deleteStudent(@PathVariable("id") Integer id)
	{
		Student student=findStudentById(id);
		studentService.delete(student);
	}
	
}
