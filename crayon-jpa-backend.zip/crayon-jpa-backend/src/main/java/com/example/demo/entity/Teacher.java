package com.example.demo.entity;

import java.text.SimpleDateFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

//@NamedQuery(name = "byCompany", query = "select t from Teacher t where t.company=:company")
@Entity
@Table(name = "TEACHER")
public class Teacher {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	@Column(name = "firstName")
	private String firstName;
	private String lastName;
    private String emailid;
    private String qualification;
    private String pass;
    private String confirmPass;
    private String mobileNumber;
    private String role;
    @Transient
	private SimpleDateFormat sdf;
	
    public Teacher() {}

	public Teacher(Integer id, String firstName, String lastName, String emailid, String qualification, String pass,
			String confirmPass, String mobileNumber, String role, SimpleDateFormat sdf) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailid = emailid;
		this.qualification = qualification;
		this.pass = pass;
		this.confirmPass = confirmPass;
		this.mobileNumber = mobileNumber;
		this.role = role;
		this.sdf = sdf;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getConfirmPass() {
		return confirmPass;
	}

	public void setConfirmPass(String confirmPass) {
		this.confirmPass = confirmPass;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public SimpleDateFormat getSdf() {
		return sdf;
	}

	public void setSdf(SimpleDateFormat sdf) {
		this.sdf = sdf;
	}

	@Override
	public String toString() {
		return "Teacher [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", emailid=" + emailid
				+ ", qualification=" + qualification + ", pass=" + pass + ", confirmPass=" + confirmPass
				+ ", mobileNumber=" + mobileNumber + ", role=" + role + ", sdf=" + sdf + "]";
	}

	

}
