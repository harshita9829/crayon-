package com.example.demo.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "CHAPTER")
public class Chapter {

	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	
	@Column(name="chapter_name")
	private String chapterName;
	
	@ManyToOne
    @JoinColumn(name="course_id", nullable=false)
    private Course course;
	
	@OneToMany(mappedBy="chapter")
	@JsonIgnore
	private Set<Lecture> lecture;
	
	public Chapter() {}
	
	
	public Chapter(Integer id, String chapterName, Course course) {
		super();
		this.id = id;
		this.chapterName = chapterName;
		this.course = course;
	}


	public Chapter(Integer id, String chapterName, Course course, Set<Lecture> lecture) {
		super();
		this.id = id;
		this.chapterName = chapterName;
		this.course = course;
		this.lecture = lecture;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getChapterName() {
		return chapterName;
	}
	public void setChapterName(String chapterName) {
		this.chapterName = chapterName;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	public Set<Lecture> getLecture() {
		return lecture;
	}
	public void setLecture(Set<Lecture> lecture) {
		this.lecture = lecture;
	}
//	@Override
//	public String toString() {
//		return "Chapter [id=" + id + ", chapterName=" + chapterName + ", course=" + course + ", lecture=" + lecture
//				+ "]";
//	}


	@Override
	public String toString() {
		return "Chapter [id=" + id + ", chapterName=" + chapterName + ", course=" + course + ", lecture=" + lecture
				+ "]";
	}

	
	
}
