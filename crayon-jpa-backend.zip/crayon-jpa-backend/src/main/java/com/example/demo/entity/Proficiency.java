package com.example.demo.entity;

public enum Proficiency {

	
		BEGINNER,
		INTERMEDIATE,
		ADVANCED,
		EXPERT
	
}
