package com.example.demo.repository;




import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Course;
import com.example.demo.entity.Enrollment;
import com.example.demo.entity.User;



@Repository

public interface EnrollmentRepository extends JpaRepository<Enrollment, Integer>
{
//	SELECT * FROM Course WHERE id in (SELECT COURSE_ID FROM ENROLLMENT WHERE STUDENT_ID=?)
	@Query("select c from Course c where c.id in (select e.courseId from Enrollment e where e.studentId=:studentId)")
	public List<Course> findCoursesByStudentid(@Param("studentId")Integer studentId);
	

	}


