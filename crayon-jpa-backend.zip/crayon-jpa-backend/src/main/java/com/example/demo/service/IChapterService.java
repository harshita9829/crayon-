package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Chapter;

public interface IChapterService {

	void createChapter(Chapter chapter);

	List<Chapter> readAllChapter();

	void updateChapter(Chapter chapter);

	Chapter readChapterById(Integer id);

	void deleteChapter(Chapter chapter);

}