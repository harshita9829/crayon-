package com.example.demo.entity;

import javax.persistence.Id;

public class Login {

	@Id
	private String email;
	@Id
	private String emailid;
	private Integer studentid;
	private Integer teacherid;
	private String role;
	
}
