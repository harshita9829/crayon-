package com.example.demo.entity;

import java.text.SimpleDateFormat;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "LECTURES")
public class Lecture {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	@Column(name = "name")
	private String name;
	@Lob
	private byte[] type;
	
	@ManyToOne
    @JoinColumn(name="chapter_id", nullable=false)
    private Chapter chapter;
	@Transient
	private SimpleDateFormat sdf;
	
	public Lecture() {}
	
	
	public Lecture(Integer id, String name, byte[] type, Chapter chapter) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.chapter = chapter;
	}


	public Lecture(Integer id, String name, Chapter chapter) {
		super();
		this.id = id;
		this.name = name;
		this.chapter = chapter;
	}

	public Lecture(Integer id, String name, byte[] type) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
	}
	public Lecture(String name, byte[] type) {
		super();
		this.name = name;
		this.type = type;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public byte[] getType() {
		return type;
	}
	public void setType(byte[] type) {
		this.type = type;
	}

	

	public Chapter getChapter() {
		return chapter;
	}


	public void setChapter(Chapter chapter) {
		this.chapter = chapter;
	}


	@Override
	public String toString() {
		return "Lecture [id=" + id + ", name=" + name + ", type=" + Arrays.toString(type) + ", chapter=" + chapter.getChapterName()
				+ "]";
	}
	

}
