package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	@GetMapping("/")
	public List<User> all()
	{
		System.out.println("all method....................................");
		return userService.read();
	}
	
	@GetMapping("/{email}/{password}")
	public User validateLogin(@PathVariable("email")String email,@PathVariable("password") String password, HttpSession session)
	{
		User user = userService.read(email, password);
		session.setAttribute("user", user);
		return user;
	}
	@PostMapping("/")
	public User registerUser(@RequestBody User user)
	{
		return userService.create(user);
	}
	@PutMapping("/")
	public User modifyUser(@RequestBody User user)
	{
		return userService.update(user);
	}
	@DeleteMapping("/{email}")
	public void deleteUser(@PathVariable("email") String email)
	{
		userService.delete(email);
	}
	@GetMapping("/dummy")
	public String dummy(HttpSession session)
	{
		User user=(User) session.getAttribute("user");
		System.out.println("Dummy says: "+user);
		if(user==null)
			return "You have not logged in";
		else
			return "You are "+user.getRole();
	}
}
