package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Student;
import com.example.demo.repository.StudentRepository;



@Component("studentService")
public class StudentService implements IStudentService {
	@Autowired
	private StudentRepository studentRepository;
	@Override
	public void create(Student student)
	{
		studentRepository.save(student);
	}
	@Override
	public List<Student> read()
	{
		return studentRepository.findAll();
	}
	@Override
	public Student read(Integer id)
	{
		return studentRepository.findById(id).get();
	}
	@Override
	public void update(Student student)
	{
		studentRepository.save(student);
	}
	@Override
	public void delete(Student student)
	{
		studentRepository.delete(student);
	}
	

}
